import org.joml.Matrix4f;
import org.joml.Vector3f;

public class Camera {

	public static final String Movement = null;

	public Camera(Vector3f vector3f) {
		// TODO Auto-generated constructor stub
	}

	public void setPerspective(float f, float g, float h, float i) {
		// TODO Auto-generated method stub
		
	}

	public Matrix4f getViewMatrix() {
		// TODO Auto-generated method stub
		return null;
	}

	public Matrix4f getProjectionMatrix() {
		// TODO Auto-generated method stub
		return null;
	}

}
