package org.lwjgl.glfw;

import java.io.PrintStream;

public class GLFWErrorCallback {

	public static Object createPrint(PrintStream err) {
		// TODO Auto-generated method stub
		return null;
	}

}
