package org.lwjgl.glfw;

public class GLFW {

}
