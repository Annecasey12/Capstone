package org.lwjgl.system;

public class MemoryUtil {

}
