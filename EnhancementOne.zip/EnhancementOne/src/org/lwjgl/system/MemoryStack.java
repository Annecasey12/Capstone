package org.lwjgl.system;

public class MemoryStack {

}
