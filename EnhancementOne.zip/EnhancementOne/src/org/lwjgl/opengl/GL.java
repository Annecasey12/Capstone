package org.lwjgl.opengl;

public record GL() {

	public static void destroy() {
		// TODO Auto-generated method stub
		
	}

}
