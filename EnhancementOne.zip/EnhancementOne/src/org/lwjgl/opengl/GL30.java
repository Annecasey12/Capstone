package org.lwjgl.opengl;

public class GL30 {

}
