package org.joml;

public class Vector4f {

}
