package org.joml;

public class Vector3f {

	public Vector3f(float f, float g, float h) {
		// TODO Auto-generated constructor stub
	}

}
