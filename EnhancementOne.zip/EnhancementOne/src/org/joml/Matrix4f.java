package org.joml;

public class Matrix4f {

	public void translate(Vector3f lightPosition) {
		// TODO Auto-generated method stub
		
	}

	public void scale(Vector3f lightScale) {
		// TODO Auto-generated method stub
		
	}

}
