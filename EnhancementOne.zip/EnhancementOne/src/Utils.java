
public class Utils {

	public static Object loadResource(String fragmentShaderPath) {
		// TODO Auto-generated method stub
		return null;
	}

}
