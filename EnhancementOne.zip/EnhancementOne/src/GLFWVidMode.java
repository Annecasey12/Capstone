
public class GLFWVidMode {

}
