import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;
import static org.lwjgl.system.MemoryStack.*;
import static org.lwjgl.system.MemoryUtil.*;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public class Main {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
	private static final long NULL = 0;
	private static final String GL_TRIANGLES = null;
	private static final String GLFW_KEY_ESCAPE = null;
	private static final String GLFW_KEY_W = null;
	private static final String GLFW_KEY_S = null;
	private static final String GLFW_PRESS = null;
	private static final String GLFW_KEY_D = null;
	private static final String GL_VERTEX_SHADER = null;
	private static final String GL_COMPILE_STATUS = null;
	private static final String GL_FRAGMENT_SHADER = null;
	private static final String GL_LINK_STATUS = null;
	private static final String GL_FALSE = null;

    private static long window;

    private static int vaoId;
    private static int vboId;
    private static int vertexCount;

    private static int textureId;
    private static Vector2f uvScale = new Vector2f();
    private static int texWrapMode = HEIGHT;

    private static int cubeProgramId;
    private static int lampProgramId;

    private static Camera camera = new Camera(new Vector3f(0.0f, 0.0f, 7.0f));
    private static float lastX = WIDTH / 2.0f;
    private static float lastY = HEIGHT / 2.0f;
    private static boolean firstMouse = true;

    private static float deltaTime = 0.0f;
    private static float lastFrame = 0.0f;

    private static Vector3f cubePosition = new Vector3f(0.0f, 0.0f, 0.0f);
    private static Vector3f cubeScale = new Vector3f(2.0f, deltaTime, deltaTime);

    private static Vector3f objectColor = new Vector3f(1.f, 0.2f, 0.0f);
    private static Vector3f lightColor = new Vector3f(1.0f, 1.0f, 1.0f);

    private static Vector3f lightPosition = new Vector3f(1.5f, 0.5f, 3.0f);
    private static Vector3f lightScale = new Vector3f(0.3f);

    private static boolean isLampOrbiting = true;

    public static void main(String[] args) {
        init();
        loop();

        GL.destroy();
        glfwTerminate();
    }

    private static void glfwTerminate() {
		// TODO Auto-generated method stub
		
	}

	private static void init() {
        GLFWErrorCallback.createPrint(System.err).set();

        boolean glfwInit;
		if (!glfwInit) {
            throw new IllegalStateException("Unable to initialize GLFW");
        }

        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

        window = glfwCreateWindow(WIDTH, HEIGHT, "Tutorial 6.3", NULL, NULL);
        if (window == NULL) {
            throw new RuntimeException("Failed to create the GLFW window");
        }

        glfwSetFramebufferSizeCallback(window, (window, width, height) -> {
            glViewport(0, 0, width, height);
        });

        glfwSetCursorPosCallback(window, (window, xpos, ypos) -> {
            if (firstMouse) {
                lastX = (float) xpos;
                lastY = (float) ypos;
                firstMouse = false;
            }

            float xoffset = (float) xpos - lastX;
            float yoffset = lastY - (float) ypos;
            lastX = (float) xpos;
            lastY = (float) ypos;

            camera.processMouseMovement(xoffset, yoffset);
        });

        glfwSetCursorPosCallback(window, (window, xoffset, yoffset) -> {
            camera.processMouseScroll((float) yoffset);
        });

        try (MemoryStack stack = stackPush()) {
            IntBuffer pWidth = stack.mallocInt(1);
            IntBuffer pHeight = stack.mallocInt(1);

            glfwGetWindowSize(window, pWidth, pHeight);

            GLFWVidMode vidmode = glfwGetVideoMode(glfwGetPrimaryMonitor());
            glfwSetWindowPos(
                    window,
                    (vidmode.width() - pWidth.get(0)) / 2,
                    (vidmode.height() - pHeight.get(0)) / 2
            );
        }

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1);
        glfwShowWindow(window);

        GL.createCapabilities();

        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);

        glEnable(GL_DEPTH_TEST);

        cubeProgramId = createShaderProgram("cube_vertex.glsl", "cube_fragment.glsl");
        lampProgramId = createShaderProgram("lamp_vertex.glsl", "lamp_fragment.glsl");

        GLMesh gMesh = createMesh();

        Object gTextureId = loadTexture("container.jpg");

        camera.setPerspective(45.0f, (float) WIDTH / HEIGHT, 0.1f, 100.0f);
    }

    private static Object loadTexture(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	private static Object glfwGetPrimaryMonitor() {
		// TODO Auto-generated method stub
		return null;
	}

	private static void glfwGetWindowSize(long window2, IntBuffer pWidth, IntBuffer pHeight) {
		// TODO Auto-generated method stub
		
	}

	private static void glfwSetCursorPosCallback(long window2, Object object) {
		// TODO Auto-generated method stub
		
	}

	private static void glfwSetFramebufferSizeCallback(long window2, Object object) {
		// TODO Auto-generated method stub
		
	}

	private static void glfwDefaultWindowHints() {
		// TODO Auto-generated method stub
		
	}

	private static void loop() {
        while (!glfwWindowShouldClose(window)) {
            float currentFrame = (float) glfwGetTime();
            deltaTime = currentFrame - lastFrame;
            lastFrame = currentFrame;

            processInput(window);

            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

            glUseProgram(cubeProgramId);

            int modelLoc = glGetUniformLocation(cubeProgramId, "model");
            int viewLoc = glGetUniformLocation(cubeProgramId, "view");
            int projectionLoc = glGetUniformLocation(cubeProgramId, "projection");
            int objectColorLoc = glGetUniformLocation(cubeProgramId, "objectColor");
            int lightColorLoc = glGetUniformLocation(cubeProgramId, "lightColor");
            int lightPositionLoc = glGetUniformLocation(cubeProgramId, "lightPosition");
            int viewPositionLoc = glGetUniformLocation(cubeProgramId, "viewPosition");

            glUniform3fv(objectColorLoc, objectColor.get(new float[3]));
            glUniform3fv(lightColorLoc, lightColor.get(new float[3]));
            glUniform3fv(lightPositionLoc, lightPosition.get(new float[3]));
            glUniform3fv(viewPositionLoc, camera.getPosition().get(new float[3]));

            Object model;
			Matrix4f model = new Matrix4f();
            model.translate(cubePosition);
            model.scale(cubeScale);

            Matrix4f view = camera.getViewMatrix();

            Matrix4f projection = camera.getProjectionMatrix();

            glUniformMatrix4fv(modelLoc, false, model.get(new float[16]));
            glUniformMatrix4fv(viewLoc, false, view.get(new float[16]));
            glUniformMatrix4fv(projectionLoc, false, projection.get(new float[16]));

            glBindVertexArray(vaoId);
            glDrawArrays(GL_TRIANGLES, 0, vertexCount);

            glUseProgram(lampProgramId);

            modelLoc = glGetUniformLocation(lampProgramId, "model");
            viewLoc = glGetUniformLocation(lampProgramId, "view");
            projectionLoc = glGetUniformLocation(lampProgramId, "projection");

            model = new Matrix4f();
            model.translate(lightPosition);
            model.scale(lightScale);

            glUniformMatrix4fv(modelLoc, false, model.get(new float[16]));
            glUniformMatrix4fv(viewLoc, false, view.get(new float[16]));
            glUniformMatrix4fv(projectionLoc, false, projection.get(new float[16]));

            glBindVertexArray(vaoId);
            glDrawArrays(GL_TRIANGLES, 0, vertexCount);

            glfwSwapBuffers(window);
            glfwPollEvents();
        }
    }

    private static void glfwPollEvents() {
		// TODO Auto-generated method stub
		
	}

	private static void glfwSwapBuffers(long window2) {
		// TODO Auto-generated method stub
		
	}

	private static void glBindVertexArray(int vaoId2) {
		// TODO Auto-generated method stub
		
	}

	private static int glGetUniformLocation(int cubeProgramId2, String string) {
		// TODO Auto-generated method stub
		return 0;
	}

	private static void processInput(long window) {
        if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
            glfwSetWindowShouldClose(window, true);
        }

        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
            camera.processKeyboard(Camera.Movement.FORWARD, deltaTime);
        }
        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
            camera.processKeyboard(Camera.Movement.BACKWARD, deltaTime);
        }
        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
            camera.processKeyboard(Camera.Movement.LEFT, deltaTime);
        }
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
            camera.processKeyboard(Camera.Movement.RIGHT, deltaTime);
        }
    }

    private static void glfwSetWindowShouldClose(long window2, boolean b) {
		// TODO Auto-generated method stub
		
	}

	private static int createShaderProgram(String vertexShaderPath, String fragmentShaderPath) {
        int vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vertexShaderId, Utils.loadResource(vertexShaderPath));
        glCompileShader(vertexShaderId);
        if (glGetShaderi(vertexShaderId, GL_COMPILE_STATUS) == GL_FALSE) {
            throw new RuntimeException("Failed to compile vertex shader: " + glGetShaderInfoLog(vertexShaderId));
        }

        int fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fragmentShaderId, Utils.loadResource(fragmentShaderPath));
        glCompileShader(fragmentShaderId);
        if (glGetShaderi(fragmentShaderId, GL_COMPILE_STATUS) == GL_FALSE) {
            throw new RuntimeException("Failed to compile fragment shader: " + glGetShaderInfoLog(fragmentShaderId));
        }

        int programId = glCreateProgram();
        glAttachShader(programId, vertexShaderId);
        glAttachShader(programId, fragmentShaderId);
        glLinkProgram(programId);
        if (glGetProgrami(programId, GL_LINK_STATUS) == GL_FALSE) {
            throw new RuntimeException("Failed to link shader program: " + glGetProgramInfoLog(programId));
        }

        glCreateShader(vertexShaderId);
        glCreateShader(fragmentShaderId);

        return programId;
    }

    private static String glGetShaderInfoLog(int vertexShaderId) {
		// TODO Auto-generated method stub
		return null;
	}

	private static void glShaderSource(int vertexShaderId, Object loadResource) {
		// TODO Auto-generated method stub
		
	}

	private static String glGetShaderi(int fragmentShaderId, String glCompileStatus) {
		// TODO Auto-generated method stub
		return null;
	}

	private static void glCompileShader(int fragmentShaderId) {
		// TODO Auto-generated method stub
		
	}

	private static int glCreateShader(String glFragmentShader) {
		// TODO Auto-generated method stub
		return 0;
	}

	private static String glGetProgramInfoLog(int programId) {
		// TODO Auto-generated method stub
		return null;
	}

	private static void glLinkProgram(int programId) {
		// TODO Auto-generated method stub
		
	}

	private static void glAttachShader(int programId, int vertexShaderId) {
		// TODO Auto-generated method stub
		
	}

	private static int glCreateProgram() {
		// TODO Auto-generated method stub
		return 0;
	}

	private static int glCreateShader(int vertexShaderId) {
		// TODO Auto-generated method stub
		return 0;
		)
	

	private static GLMesh createMesh() {
        float[] vertices = {
                // positions          // normals           // texture coordinates
                -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
                 0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
                 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
                 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
                -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
                -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

                -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
                 0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
                 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
                 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
                -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
                -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,

                -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
                -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
                -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
                -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
                -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
                -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

                 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
                 0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
                 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
                 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
                   






            


